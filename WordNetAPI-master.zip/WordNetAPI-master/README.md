WordNetAPI
==========

This project contains the WordNet C# API written by Matt Gerber of Michgan State University, it includes all required dependencies to build in one step.

Project hompage: https://ptl.sys.virginia.edu/ptl/members/matthew-gerber/software#wordnet
